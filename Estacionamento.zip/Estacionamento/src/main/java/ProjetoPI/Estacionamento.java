package ProjetoPI;

import java.util.Date;

public class Estacionamento {

    private double valor = 0;
    private Vaga vagas[];
    private double valorHora;
    private double valorRecebidoTotal;

    public Estacionamento(int vagasDisponivel) {
        this.iniciaVagas(vagasDisponivel);
        this.valorHora = 5;
    }

    private void iniciaVagas(int vagasDisponivel) {
        this.vagas = new Vaga[vagasDisponivel];

        for (int i = 0; i < vagasDisponivel; i++) {
            this.vagas[i] = new Vaga();
        }
    }

    public void estacionar(Carro carro) {
        Vaga vaga = this.proximaVagaLivre();

        vaga.ocupar(carro);
    }

    public Double calcularValor(Vaga vaga, String placa) {
        valor = vaga.getValorTotal(this.valorHora);
        this.recebePagamento(valor);
        return valor;
    }

    public String sair(String placa) {
        String informacaoSaida = "";

        Vaga vaga = this.procurarVagaComCarro(placa);

        if (vaga != null) {

            informacaoSaida = vaga.toString() + "\nData Saida: " + new Date() + "\nValor pago: " + valor + "\n";

            // sai da vaga
            vaga.desocupar();
        } else {
            informacaoSaida = "Carro não encontrado: " + placa;
        }

        return informacaoSaida;
    }

    public Vaga procurarVagaComCarro(String placa) {
        Vaga vaga = null;
        Carro carro = new Carro(placa);

        for (Vaga vaga1 : this.vagas) {
            if (vaga1.isCarroEstacionado(carro)) {
                vaga = vaga1;
            }
        }

        return vaga;
    }

    public Vaga proximaVagaLivre() {
        Vaga vaga = null;
        for (int i = 0; i < this.vagas.length; i++) {
            if (this.vagas[i].estaOcupada() == false) {
                vaga = vagas[i];
                break;
            }
        }

        return vaga;
    }

    public void recebePagamento(double valor) {
        this.valorRecebidoTotal = this.valorRecebidoTotal + valor;
    }

    public double getTotalRecebido() {
        return this.valorRecebidoTotal;
    }

}
