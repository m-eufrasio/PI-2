package ProjetoPI;

import dao.RegistroDAO;
import java.sql.SQLException;
import java.util.Scanner;

public class Testee {

    private static void Start() {
        System.out.println("1- Registro de Entrada\n" + "2- Efetuar Pagamento\n" + "3- Valor total no dia\n" + "4- Desligar\n");
    }

    public static void main(String[] args) throws SQLException {
        int vagas = 2;
        int op;
        RegistroDAO registroDAO = new RegistroDAO();
        Scanner t = new Scanner(System.in);
        Estacionamento estacionamento = new Estacionamento(vagas);
        String placa = "";
        Double valor = 0.0;
        OUTER_1:
        while (true) {
            Start();
            op = t.nextInt();
            switch (op) {
                case 1:
                    //placa e entrada
                    //insert
                    if (vagas == 0) {
                        System.out.println("Estacionamento lotado");
                        break;
                    }
                    System.out.println("Vagas Disponiveis:" + vagas);
                    System.out.println(" ");

                    System.out.println("Digite a placa para registro:");
                    placa = t.next();
                    Carro carro = new Carro(placa);
                    estacionamento.estacionar(carro);
                    Registro registro = new Registro();
                    registro.setPlaca(placa);
                    registroDAO.inserir(registro);
                    System.out.println("Ticket gerado com sua placa: " + placa);
                    System.out.println("");
                    vagas--;
                    break;
                case 2:
                    OUTER:
                    while (true) {
                        System.out.println("Digite a placa para receber o valor:");
                        placa = t.next();
                        Vaga vaga = estacionamento.procurarVagaComCarro(placa);
                        if (vaga != null) {
                            valor = estacionamento.calcularValor(vaga, placa);
                            System.out.println(vaga.toString() + "\nValor: " + valor);
                        } else {
                            System.out.println("Carro não encontrado: " + placa);
                            break;
                        }
                        System.out.println(valor);
                        System.out.println("Forma de pagamento: 1-Dinheiro  2-Cartão ou 3-Voltar menu");
                        int escolha = t.nextInt();
                        while (true) {
                            switch (escolha) {
                                case 1: {
                                    //update
                                    System.out.println("1 -Digite a placa novamente para retirar:");
                                    String saida = t.next();
                                    saida = estacionamento.sair(saida);
                                    System.out.println(saida);
                                    vagas++;
                                    break OUTER;
                                }
                                case 2: {
                                    System.out.println("Insira o cartão");
                                    tempoDeEspera(2);
                                    System.out.println("Digite a placa novamente para retirar:");
                                    String saida = t.next();
                                    saida = estacionamento.sair(saida);
                                    System.out.println(saida);
                                    System.out.println("Retire o cartão\n");
                                    vagas++;
                                    break OUTER;
                                }
                                case 3:
                                    break OUTER;
                                default:
                                    break;
                            }
                        }
                    }
                    registro = new Registro();
                    registro.setPlaca(placa);
                    registro.setValor(valor);
                    registroDAO.alterar(registro);
                    break;
                case 3:
                    // Total recebido ate o momento.
                    System.out.println("\nValor total ate o momento: " + estacionamento.getTotalRecebido());
                    break;
                case 4:
                    System.out.println("__Desligando__");
                    break OUTER_1;
                default:
                    break;
            }
        }

    }

    public static void tempoDeEspera(int segundos) {
        try {
            Thread.sleep(segundos * 1000);
        } catch (InterruptedException e) {

        }
    }
}
