package dao;

import bd.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import ProjetoPI.Registro;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class RegistroDAO {

    private final Conexao db = new Conexao();

    public boolean inserir(Registro registro) throws SQLException {
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO registro(placa, entrada) VALUES(?,now())");
        Connection conn = db.getConnection();
        try {
            PreparedStatement stmt = conn.prepareStatement(sql.toString());
            stmt.setString(1, registro.getPlaca());
            //stmt.setDate(2, java.sql.Date.valueOf(java.time.LocalDate.now()));
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        } finally {
            conn.close();
        }
    }

    public boolean alterar(Registro registro) throws SQLException {
        String sql = "UPDATE registro SET saida = now(), valor = ? WHERE placa = ? and saida is null";
        Connection conn = db.getConnection();
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            //stmt.setTimestamp(1, java.sql.Date.valueOf(java.time.LocalDateTime.now()));
            stmt.setDouble(1, registro.getValor());
            stmt.setString(2, registro.getPlaca());
            int teste = stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Registro.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } finally {
            conn.close();
        }
    }

}
